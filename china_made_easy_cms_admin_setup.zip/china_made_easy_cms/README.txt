CHINA MADE EASY — CMS ADMIN STARTER

Files in this package:
- admin/index.html: CMS entry page
- admin/config.yml: content editor configuration
- content/tutorials/: tutorial content files created by the CMS
- content/cities/: city guide content files created by the CMS
- assets/uploads/: uploaded images

IMPORTANT:
This package adds the CMS admin interface and content storage structure.
The current homepage is still a hand-coded static HTML page. The tutorial/city content created in this CMS will NOT automatically appear on the public homepage until the frontend is connected to these content files in a separate integration step.

Setup steps:
1. Add these folders/files to the root of the GitHub repository china-made-easy, keeping the paths exactly as shown.
2. Commit the changes to branch main.
3. In Netlify, open the china-made-easy site.
4. Enable Identity (if available in your site settings) and set Registration to Invite only.
5. Enable Git Gateway under Identity services.
6. Invite your own email under Identity users, then accept the invitation and set a password.
7. Open https://china-made-easy.netlify.app/admin/ and sign in.

Compatibility note:
Netlify currently marks Git Gateway as deprecated and does not recommend new setups. This starter uses it because it is the simplest CMS path historically supported by Netlify. If Git Gateway is unavailable in your account, stop here rather than enabling public registration; use a modern GitHub-authenticated CMS backend instead.
