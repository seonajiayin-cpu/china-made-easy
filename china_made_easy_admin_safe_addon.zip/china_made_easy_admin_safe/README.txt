SAFE ADD-ON PACKAGE — CHINA MADE EASY

This package contains ONLY new/add-on files. It deliberately excludes the existing homepage index.html so it cannot overwrite your current website homepage when extracted/uploaded.

Files to add to the root of your existing GitHub repository:
- admin/index.html
- admin/config.yml
- content/tutorials/*.md
- assets/uploads/.gitkeep

IMPORTANT:
The CMS is not yet ready for publishing. Its current config uses Netlify Git Gateway, which requires authentication/backend setup and is deprecated for new setups. Do not treat the admin page as live until we complete a supported authentication setup and test it.
