---
title: How to Order Food in China
description: Order food at a restaurant or through a delivery app.
category: Food & Daily Life
icon: 🍜
panda_tip: If you have allergies, show a written Chinese explanation and confirm with staff.
steps:
  - step_title: Choose how to order
    instruction: Order at the restaurant, use a QR menu or use a food delivery service.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Browse the menu
    instruction: Use translation tools or pictures to understand the dishes.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Confirm your order
    instruction: Check dishes, quantities and any special requests before submitting.
    screenshot: ""
    caption: ""
    tip: ""
common_problems: []
useful_chinese: []
---
