---
title: How to Set Up Alipay
description: Create an account and prepare a payment method.
category: Payments
icon: 💳
panda_tip: Complete verification and add a payment method before you need to pay in a shop.
steps:
  - step_title: Download Alipay
    instruction: Install Alipay from your phone's app store and open it.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Register your account
    instruction: Follow the registration prompts using your mobile number.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Verify your identity
    instruction: Follow the in-app instructions for identity verification. Requirements may vary.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Add a payment card
    instruction: Add a supported bank card and follow the prompts.
    screenshot: ""
    caption: ""
    tip: ""
common_problems: []
useful_chinese: []
---
