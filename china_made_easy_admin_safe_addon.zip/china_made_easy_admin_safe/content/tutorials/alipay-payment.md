---
title: How to Pay with Alipay
description: Learn the two common ways to pay with Alipay.
category: Payments
icon: 💳
panda_tip: Check the amount and merchant name before confirming payment.
steps:
  - step_title: Open the payment screen
    instruction: Open Alipay and choose the payment option appropriate for the shop's QR code.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Scan or show your QR code
    instruction: Follow the merchant's instructions to scan their code or show your payment code.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Confirm payment
    instruction: Check the amount and confirm. Wait for the payment success message.
    screenshot: ""
    caption: ""
    tip: ""
common_problems: []
useful_chinese: []
---
