---
title: How to Take the Metro
description: Navigate China's metro systems with confidence.
category: Transportation
icon: 🚇
panda_tip: Keep your destination name in Chinese handy if you need help.
steps:
  - step_title: Find your route
    instruction: Use a map app or the station map to identify your line and direction.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Enter the station
    instruction: Follow signs to the correct entrance and security checkpoint.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Pay and pass the gate
    instruction: Use the available ticket, transit card or supported QR payment method.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Exit at your destination
    instruction: Follow station signs and check the exit number for your destination.
    screenshot: ""
    caption: ""
    tip: ""
common_problems: []
useful_chinese: []
---
