---
title: Essential Apps for China
description: The apps that make travelling in China easier.
category: Internet & Apps
icon: 📱
panda_tip: Download and set up essential apps before you arrive, when possible.
steps:
  - step_title: Prepare your phone
    instruction: Make sure your phone has enough storage and can access the app store you normally use.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Install essential apps
    instruction: Prepare payment, maps, translation, transport and communication apps before your trip.
    screenshot: ""
    caption: ""
    tip: ""
common_problems: []
useful_chinese: []
---
