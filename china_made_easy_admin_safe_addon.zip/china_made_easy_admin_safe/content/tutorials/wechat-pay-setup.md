---
title: Set Up WeChat Pay
description: Prepare WeChat Pay for your trip.
category: Payments
icon: 💬
panda_tip: Set up a backup payment method in case one payment option is unavailable.
steps:
  - step_title: Install WeChat
    instruction: Download WeChat and register or sign in.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Open WeChat Pay
    instruction: Find the Wallet or Pay section and follow the prompts available to your account.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Add a supported card
    instruction: Follow the in-app instructions to add a supported payment card.
    screenshot: ""
    caption: ""
    tip: ""
common_problems: []
useful_chinese: []
---
