---
title: How to Use DiDi
description: Book a ride using a ride-hailing app.
category: Transportation
icon: 🚕
panda_tip: Confirm the car plate, driver and pickup point before getting in.
steps:
  - step_title: Open the ride-hailing service
    instruction: Open DiDi or the supported ride-hailing service available to you.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Enter your destination
    instruction: Search for your destination and select the correct location.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Confirm pickup and ride
    instruction: Check the pickup point, ride type and fare information before confirming.
    screenshot: ""
    caption: ""
    tip: ""
  - step_title: Find your driver
    instruction: Verify the vehicle and licence plate before boarding.
    screenshot: ""
    caption: ""
    tip: ""
common_problems: []
useful_chinese: []
---
